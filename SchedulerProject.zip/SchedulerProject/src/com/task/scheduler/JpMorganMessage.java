package com.task.scheduler;

import java.util.ArrayList;
import java.util.List;

public class JpMorganMessage implements Message {

	
	private int groupID;
	private int messageID;
	private boolean completed = false;
	private boolean groupCancelled=false;
	private List<JpMorganMessage> messages;

	
	public JpMorganMessage(final int groupID, final int messageID) {
		this.groupID = groupID;
		this.messageID = messageID;
	}
	public JpMorganMessage() {
		super();
	}

	public void completed() {
		this.completed = true;
	}

	public boolean isCompleted() {
		return this.completed;
	}

	public int getGroupID() {
		return groupID;
	}

	public int getMessageID() {
		return messageID;
	}
	
	public List<JpMorganMessage> getMessages() {
		return messages;
	}

	public void setMessages(List<JpMorganMessage> messages) {
		this.messages = messages;
	}

	public void createMessages(int n) {
		messages=new ArrayList<JpMorganMessage>();
		
		for (int i = 0; i < n; i++) {
		
			switch (i) {

			case 0:
			case 1:
				JpMorganMessage myMessage = new JpMorganMessage(1,i);
				messages.add(myMessage);
						
				break;

			case 2:
			case 3:
				JpMorganMessage myMessage1 = new JpMorganMessage(1,i);
				messages.add(myMessage1);
				break;

			case 4:
			case 5:
				JpMorganMessage myMessage2 = new JpMorganMessage(2,i);
				messages.add(myMessage2);
				break;

			default:
				JpMorganMessage myMessage3 = new JpMorganMessage(3,i);
				messages.add(myMessage3);

		}

	}
  }
	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}
	public void setMessageID(int messageID) {
		this.messageID = messageID;
	}
	public boolean isGroupCancelled() {
		return groupCancelled;
	}
	public void setGroupCancelled(boolean groupCancelled) {
		this.groupCancelled = groupCancelled;
	}
	public List<JpMorganMessage> removeCanclledGroupMessages(Integer canclledGroup,
			List<JpMorganMessage> messages2) {
		List<JpMorganMessage> msgList=new ArrayList<JpMorganMessage>();
		for(JpMorganMessage msg:messages2){
			if(!canclledGroup.equals(msg.getGroupID())){
				msgList.add(msg);
			}
			
		}
		return msgList;
		
		
	}
}
