package com.task.scheduler;

/**
 * Process message before sending to Resources.
 *
 */
public interface Gateway {
	
	public void send(Message message);

}
