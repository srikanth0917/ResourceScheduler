package com.task.scheduler;


import java.util.List;

import com.task.scheduler.strategy.GroupPriorityStrategy;
import com.task.scheduler.strategy.MessageChooser;

/**
 * Process and send correct messages to the Gateway.
 *
 */
public class MessageEngine implements Gateway{

	
	private MessageChooser messageChooser;
	private ResourceChecker resourceChecker;

	public MessageEngine(final MessageEngineConfiguration config
			) {
	
		resourceChecker = new ResourceChecker(config.getResources());
		messageChooser=new MessageChooser(new GroupPriorityStrategy());
	//	messageChooser.changeStrategy(config.getMessageChooserStrategy());
		
	}

	
	public void receiveMessage(final JpMorganMessage message) {
		
		
		if (!resourceChecker.isResourceAvailable()) {
			System.out.println("processMessage:");
			messageChooser.processMessage(message);
		} else {
									
			int resourceId=resourceChecker.getNextAvailableResource();
			
			Thread resourceCheckerThread = new Thread(resourceChecker);
			
			resourceCheckerThread.start();
				resourceChecker.updateAvailableResource(resourceId,true);
				System.out.println("next available resource:" + resourceId);
				 
				if (messageChooser.hasNext()) {
					JpMorganMessage myMessage=(JpMorganMessage) messageChooser.getNext();
					System.out.println("Message GroupID:"
							+ myMessage.getGroupID() +" " + "Message ID:"
							+ myMessage.getMessageID());
					resourceChecker.addInProgressMessages(message,resourceId);
					send(myMessage);
					message.completed();
					
				} else {
					System.out.println("Message GroupID:"
							+ message.getGroupID() +" "+ "Message ID:"
							+ message.getMessageID());
					resourceChecker.addInProgressMessages(message,resourceId);
					send(message);
					message.completed();
									
					// sendMessageToGateway(messageChooser.getNext());
					
				}
			}
		
		
		

	}

	



	public void send(Message message) {
		//calls external resource
		System.out.println("Gateway.send method called");
	}
	
	
public static void main(String[] args) {
		
		JpMorganMessage myJpMorganMessage=new JpMorganMessage();
		MessageEngineConfiguration myMessageEngineConfiguration=new MessageEngineConfiguration();
		MessageEngine myMessageEngine= new MessageEngine(myMessageEngineConfiguration);
		myMessageEngineConfiguration.getResources();
		int numerOfMessages=myMessageEngineConfiguration.getNumerOfMessages();
		myJpMorganMessage.createMessages(numerOfMessages);
		List<JpMorganMessage> messages=myJpMorganMessage.getMessages();
		//find any group is cancelled, once canclled no messages from that group will be sent to the Gateway 
		Integer canclledGroup=null;
		canclledGroup=findCancelledGroup(myJpMorganMessage.getMessages());
		
		if(canclledGroup!=null){
			//this will remove the cancelled group messages from the list these wont be send to the Gateway
			messages=myJpMorganMessage.removeCanclledGroupMessages(canclledGroup,messages);
		}
		
		//if there are no resources available then no messages will be sent to the Gateway		
		if(myMessageEngineConfiguration.getResources()==0){
			System.out.println("There are no Resources available");
			return;
		}
		//if the available resources equal to the number of messages then we directly send the messages to the GateWay
		if(myMessageEngineConfiguration.getResources()==numerOfMessages){
			for(int i=1;i<=myMessageEngineConfiguration.getResources();i++){
				myMessageEngine.send((JpMorganMessage)messages.get(i-1));
			}
		}else{
			//more messages / less messages than the number of resources available then we process the message one by one
		if (messages != null) {
			
			for (JpMorganMessage m : messages) {
				myMessageEngine.receiveMessage(m);
			}
		}
	}

	}


private static Integer findCancelledGroup(List<JpMorganMessage> messages) {
	for(JpMorganMessage m:messages){
		if(m.isGroupCancelled()){
			return m.getGroupID();
		}
	}
	return null;
}
}
