package com.task.scheduler.strategy;

import java.util.ArrayList;
import java.util.List;

import com.task.scheduler.JpMorganMessage;

public class GroupPriorityStrategy implements MessageChooserStrategy {

	private List<JpMorganMessage> prioristisedMessages = new ArrayList<JpMorganMessage>();
	
	private List<JpMorganMessage> processingMsgs = new ArrayList<JpMorganMessage>();
	


	public synchronized void processMsg(JpMorganMessage message) {
		//process message by ordering based on group priority and add it to 
		// prioristisedMessages
		if(prioristisedMessages.isEmpty()){
			prioristisedMessages.add(message);
			processingMsgs.add(message);
		}else{
					
			if(checkForTheGroup(processingMsgs,message.getGroupID())){
				JpMorganMessage myMessage=getTheFirstMsgFromGroup(prioristisedMessages,message.getGroupID());
				if(myMessage!=null){
					prioristisedMessages=adjustPriorityList(prioristisedMessages,myMessage);
					prioristisedMessages.add(processingMsgs.size(), message);
				}else{
					prioristisedMessages.add(0,message);
				}
				  
				
			}else{
				prioristisedMessages.add(message);
				processingMsgs.add(message);
			}
		}
		
	}

	

	private List<JpMorganMessage> adjustPriorityList(
			List<JpMorganMessage> prioristisedMessages2, JpMorganMessage myMessage) {
		List<JpMorganMessage> myList=new ArrayList<JpMorganMessage>();
		myList.add(myMessage);
		for(JpMorganMessage msg:prioristisedMessages2){
			if(!(msg.getMessageID()==myMessage.getMessageID())){
				myList.add(msg);
			}
		}
		return myList;
	}



	private boolean checkForTheGroup(List<JpMorganMessage> processingMsgs2,
			Integer groupID) {
		for(JpMorganMessage msg:processingMsgs2){
			if (groupID.equals(msg.getGroupID())) {
				return true;
			}
			
		}
		
		return false;
	}



	private JpMorganMessage getTheFirstMsgFromGroup(
			List<JpMorganMessage> prioristisedMessages2, Integer groupID) {
		for (JpMorganMessage msg : prioristisedMessages2) {
			if (groupID.equals(msg.getGroupID()) && !msg.isCompleted()) {
				return msg;
			}
		}
		return null;
	}



	public boolean hasNext() {
		return prioristisedMessages.iterator().hasNext();
	}

	public JpMorganMessage getNext() {
		return prioristisedMessages.iterator().next();
	}
	
	public List<JpMorganMessage> getPrioristisedMessages() {
		return prioristisedMessages;
	}

	public void setPrioristisedMessages(List<JpMorganMessage> prioristisedMessages) {
		this.prioristisedMessages = prioristisedMessages;
	}
	


	public List<JpMorganMessage> getProcessingMsgs() {
		return processingMsgs;
	}

	public void setProcessingMsgs(List<JpMorganMessage> processingMsgs) {
		this.processingMsgs = processingMsgs;
	}
}
