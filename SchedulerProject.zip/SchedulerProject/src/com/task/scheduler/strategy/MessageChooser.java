package com.task.scheduler.strategy;

import com.task.scheduler.JpMorganMessage;
import com.task.scheduler.Message;

public class MessageChooser {
	private MessageChooserStrategy strategy;

	public MessageChooser(MessageChooserStrategy strategy) {
		this.strategy = strategy;
	}

	public void changeStrategy(MessageChooserStrategy strategy) {
		this.strategy = strategy;
	}

	public Message getNext() {
		return this.strategy.getNext();
	}
	
	public boolean hasNext() {
		return this.strategy.hasNext();
	}
	
	public void processMessage(final JpMorganMessage message) {
		this.strategy.processMsg(message);
	}

}
