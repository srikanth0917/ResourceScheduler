package com.task.scheduler.strategy;

import com.task.scheduler.JpMorganMessage;

public interface MessageChooserStrategy {
	public JpMorganMessage getNext();
	public boolean hasNext();
	public void processMsg(JpMorganMessage message);
}
