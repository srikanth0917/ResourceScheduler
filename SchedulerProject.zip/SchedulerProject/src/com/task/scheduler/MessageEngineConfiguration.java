package com.task.scheduler;

import com.task.scheduler.strategy.GroupPriorityStrategy;
import com.task.scheduler.strategy.MessageChooserStrategy;

/**
 * Configuration for {@link MessageEngine}
 *
 */
public class MessageEngineConfiguration {
	
	private int resources = 2;
	private int numerOfMessages=5;
	private MessageChooserStrategy messageChooserStrategy = new GroupPriorityStrategy();

	public int getResources() {
		return resources;
	}

	public void setResources(int resources) {
		this.resources = resources;
	}

	public MessageChooserStrategy getMessageChooserStrategy() {
		return messageChooserStrategy;
	}

	public void setMessageChooserStrategy(MessageChooserStrategy messageChooserStrategy) {
		this.messageChooserStrategy = messageChooserStrategy;
	}

	public int getNumerOfMessages() {
		return numerOfMessages;
	}

	public void setNumerOfMessages(int numerOfMessages) {
		this.numerOfMessages = numerOfMessages;
	}
}
