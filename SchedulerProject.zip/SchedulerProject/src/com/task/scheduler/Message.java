package com.task.scheduler;

/**
 * A callback when message processing is completed.
 * 
 */
public interface Message {
	public void completed();

}
