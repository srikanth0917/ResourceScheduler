package com.task.scheduler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ResourceChecker implements Runnable {
	
	private static final Map<Integer, Boolean> resourceAvailabilityMap = new ConcurrentHashMap<Integer, Boolean>();


	private Map<Integer, Message> inProgressMessages = new ConcurrentHashMap<Integer, Message>();
	int resourceCnt;
	
	public ResourceChecker(final int resourceCount) {
		for (int i = 1; i <= resourceCount; i++) {
			
			resourceAvailabilityMap.put(i, false);
		}
		resourceCnt=resourceCount;
	}
	
	public ResourceChecker(){
		
	}
	public int getResourceCnt() {
		return resourceCnt;
	}
	public void setResourceCnt(int resourceCnt) {
		this.resourceCnt = resourceCnt;
	}
	
	
	public void addInProgressMessages(Message message,int resourceId) {
		inProgressMessages.put(resourceId, message);
		
	}
	
	public Integer getNextAvailableResource() {
		for (int resourceId : resourceAvailabilityMap.keySet()) {
			if (!resourceAvailabilityMap.get(resourceId)) {
				return resourceId;
			}
		 }
		return 0;
	}

	public boolean isResourceAvailable() {
		return resourceAvailabilityMap.containsValue(false);	
	}
	
	public void run() {
		
		for(int resourceId : inProgressMessages.keySet()) {
			JpMorganMessage message = (JpMorganMessage)inProgressMessages.get(resourceId);
			if (message.isCompleted()) {
				inProgressMessages.remove(resourceId);
				updateAvailableResource(resourceId,false);
				
			}
		}
	}

	public Map<Integer, Message> getInProgressMessages() {
		return inProgressMessages;
	}

	

	public void updateAvailableResource(final int resourceId, boolean b) {
		resourceAvailabilityMap.put(resourceId, b);
		
	}
	
	
	
	
	


}


