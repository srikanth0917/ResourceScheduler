package com.task.scheduler.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.task.scheduler.JpMorganMessage;

public class JpMorganMessageTest {
	
	JpMorganMessage myMessage;
	
	@Before
	public void setUPMessages(){
		myMessage=new JpMorganMessage();
		myMessage.createMessages(3);
	}
	
	@After
	public void destroy(){
		System.out.println("Cancel group functionality tested");
	}
	
	@Test
	public void removeCanclledGroupMessagesTest(){
		List<JpMorganMessage> myList=myMessage.removeCanclledGroupMessages(1, myMessage.getMessages());
		assertTrue("Cancelled Group messages not deleted properly",myList.size()==0);
	}

}
