package com.task.scheduler.test;

import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.task.scheduler.JpMorganMessage;
import com.task.scheduler.strategy.GroupPriorityStrategy;

public class GroupPriorityStrategyTest {
	
	private GroupPriorityStrategy myGroupPriorityStrategy;
	private JpMorganMessage myJpMorganMessage;
	
	@Before
	public void setUpMethod(){
		myGroupPriorityStrategy=new GroupPriorityStrategy();
		myJpMorganMessage=new JpMorganMessage();
		myJpMorganMessage.createMessages(4);
	}
	
	
	
	@Test
	public void processMsgTest(){
		JpMorganMessage myMessage=new JpMorganMessage();
		myMessage.setMessageID(1);
		myMessage.setGroupID(1);
		
		myGroupPriorityStrategy.processMsg(myMessage);
		
		assertTrue("Message is not added to the prioritised messages",myGroupPriorityStrategy.getPrioristisedMessages().size()==1);
		assertTrue("Message is incorrectly added to the processing message map",myGroupPriorityStrategy.getProcessingMsgs().size()==1);
	}
	
	@Test
	public void processMsg1Test(){
		JpMorganMessage myMessage1=myJpMorganMessage.getMessages().get(0);
		myGroupPriorityStrategy.processMsg(myMessage1);
		JpMorganMessage myMessage2=new JpMorganMessage();
		myMessage2.setMessageID(2);
		myMessage2.setGroupID(1);
		myMessage1.completed();
		myGroupPriorityStrategy.processMsg(myMessage2);
		
		assertTrue("Message is not added to the prioritised messages",myGroupPriorityStrategy.getPrioristisedMessages().size()==2);
		assertTrue("Message is incorrectly added to the processing message list",myGroupPriorityStrategy.getProcessingMsgs().size()==1);
	}
	
	
	@Test
	public void processMsg2Test(){
		JpMorganMessage myMessage2=new JpMorganMessage();
		myMessage2.setMessageID(3);
		myMessage2.setGroupID(2);
		myGroupPriorityStrategy.processMsg(myMessage2);
		JpMorganMessage myMessage=new JpMorganMessage();
		myMessage.setMessageID(1);
		myMessage.setGroupID(1);
		myGroupPriorityStrategy.processMsg(myMessage);
		
		assertTrue("Message is not added to the prioritised messages",myGroupPriorityStrategy.getPrioristisedMessages().size()==2);
		assertTrue("Message is incorrectly added to the processing message list",myGroupPriorityStrategy.getProcessingMsgs().size()==2);
	}
	
	@Test
	public void adjustPriorityListTest() throws IllegalAccessException, InstantiationException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException{
		
		JpMorganMessage myMessage2=new JpMorganMessage();
		myMessage2.setMessageID(3);
		myMessage2.setGroupID(2);
		myGroupPriorityStrategy.processMsg(myMessage2);
		JpMorganMessage myMessage=new JpMorganMessage();
		myMessage.setMessageID(1);
		myMessage.setGroupID(1);
		myGroupPriorityStrategy.processMsg(myMessage);
		
		JpMorganMessage myMessage3=new JpMorganMessage();
		myMessage3.setMessageID(4);
		myMessage3.setGroupID(1);
		myGroupPriorityStrategy.processMsg(myMessage3);
		Class<?> cls=null;
		try {
			cls = Class.forName("com.task.scheduler.strategy.GroupPriorityStrategy");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object obj = cls.newInstance();
		//GroupPriorityStrategy myGroupPriorityStrategy1=new GroupPriorityStrategy();
		Method method = cls.getDeclaredMethod("adjustPriorityList",List.class,JpMorganMessage.class);
		method.setAccessible(true);
		List<?> myList=(List<?>) method.invoke(obj, myGroupPriorityStrategy.getPrioristisedMessages(),myMessage3);
		JpMorganMessage myFirstMsg=(JpMorganMessage) myList.get(0);
		
		assertTrue("Priority list is not adjusted",myFirstMsg.getMessageID()==4);
		
		
	}
	
	
	
	@Test
	public void processMsg3Test(){
		JpMorganMessage myMessage2=new JpMorganMessage();
		myMessage2.setMessageID(1);
		myMessage2.setGroupID(1);
		myGroupPriorityStrategy.processMsg(myMessage2);
		JpMorganMessage myMessage=new JpMorganMessage();
		myMessage.setMessageID(2);
		myMessage.setGroupID(1);
		myMessage.completed();
		myGroupPriorityStrategy.processMsg(myMessage);
		JpMorganMessage myMessage3=new JpMorganMessage();
		myMessage3.setMessageID(3);
		myMessage3.setGroupID(2);
		myGroupPriorityStrategy.processMsg(myMessage3);
		
		assertTrue("Message is not added to the prioritised messages",myGroupPriorityStrategy.getPrioristisedMessages().size()==3);
		assertTrue("Message is incorrectly added to the processing message list",myGroupPriorityStrategy.getProcessingMsgs().size()==2);
	}

}
