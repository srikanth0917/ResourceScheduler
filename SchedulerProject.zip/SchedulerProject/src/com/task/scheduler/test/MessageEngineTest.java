package com.task.scheduler.test;


import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.task.scheduler.JpMorganMessage;
import com.task.scheduler.MessageEngine;
import com.task.scheduler.MessageEngineConfiguration;

public class MessageEngineTest {

	private MessageEngine myMessageEngine;
	private MessageEngineConfiguration myMessageEngineConfiguration;
	private JpMorganMessage myJpMorganMessage;
	
	@Before
	public void setUpData(){
		 myMessageEngineConfiguration=new MessageEngineConfiguration();
		 myMessageEngine=new MessageEngine(myMessageEngineConfiguration);
		 myJpMorganMessage=new JpMorganMessage();
		 myJpMorganMessage.createMessages(4);	 
	}
	
	
	@Test
	public void receiveMessageTest(){
		JpMorganMessage myJpMorganMessage1 =new JpMorganMessage(); 
		myJpMorganMessage1.setMessageID(1);
		myJpMorganMessage1.setGroupID(1);
		
		myMessageEngine.receiveMessage(myJpMorganMessage1);
	
		assertTrue("",myJpMorganMessage1.isCompleted()==true);
	}
	
	@Test
	public void receiveMessage1Test(){
		JpMorganMessage myJpMorganMessage1 =new JpMorganMessage(); 
		myJpMorganMessage1.setMessageID(1);
		myJpMorganMessage1.setGroupID(1);
		JpMorganMessage myJpMorganMessage2 =new JpMorganMessage(); 
		myJpMorganMessage2.setMessageID(2);
		myJpMorganMessage2.setGroupID(2);
		List<JpMorganMessage> myList=new ArrayList<JpMorganMessage>();
		myList.add(myJpMorganMessage1);
		myList.add(myJpMorganMessage2);		
		myJpMorganMessage.setMessages(myList);
		for(JpMorganMessage msg:myList){
			myMessageEngine.receiveMessage(msg);
		}
	
		assertTrue("",myJpMorganMessage1.isCompleted()==true);
		assertTrue("",myJpMorganMessage2.isCompleted()==true);
		
	}
	
	@Test
	public void mainTest(){
		MessageEngine.main(null);	
	}
	
	
}
