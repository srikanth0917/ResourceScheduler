package com.task.scheduler.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.task.scheduler.JpMorganMessage;
import com.task.scheduler.ResourceChecker;

public class ResourceCheckerTest {
	ResourceChecker myResourceChecker;
	JpMorganMessage myMessage;
	
	@Before
	public void setUpAvailabilityMap(){
		myResourceChecker=new ResourceChecker(2);		
		myMessage=new JpMorganMessage();
		myMessage.createMessages(2);
		myMessage.getMessages().get(0);
		myResourceChecker.addInProgressMessages(myMessage.getMessages().get(0), 1);
		myResourceChecker.addInProgressMessages(myMessage.getMessages().get(1), 2);
	}

	@After
	public void Destroy(){
		
		System.out.println("Resource Checker functionality Tested");
	}
	
	@Test
	public void nextAvailableResourceTest(){
		
		Integer myReturnValue=myResourceChecker.getNextAvailableResource();
		assertEquals("Resource Not Avaialable",myReturnValue.toString(),"2");
	}
	
	@Test
	public void runTest(){
		
		myResourceChecker.run();
		assertTrue("resources and messages not updated properly",myResourceChecker.isResourceAvailable()==true);
				
	}
	
	@Test
	public void seconRunTest(){
		myMessage.getMessages().get(0).completed();
		myResourceChecker.run();
		assertTrue("completed message not removed from progressQueue",myResourceChecker.getInProgressMessages().size()==1);
		
		
	}
	
	@Test
	public void isResourceAvailableTest(){
	
		Boolean myResult=myResourceChecker.isResourceAvailable();
		assertTrue("No resources available",myResult==true);
		
	}
}
